function [Road_Long]=Algo_A_star_weight(Indus_field, startposind,goalposind, costchart,fieldpointers)
    
weight=2;
Road_Long=0;%用来存放规划的路径的长度
%Environmental_Set=0;%环境不用改，只要改始终点就行，每次记录得路径长度，然后再用GA转换去Missiondian的顺序以求的最优解，SED则用于游览不同Site之间的顺序

% 绘制初始关于障碍物以及起点和终点的图像
%axishandle = createFigure(Indus_field,costchart,startposind,goalposind);

if startposind==goalposind
    Road_Long=0;
else

    %%
    %以上为所有初始条件设定完毕，开始寻找路线,将机型， 及其数量与任务点匹配 初步线路规划A*
    % 这个while循环是本程序的核心，利用循环进行迭代来寻找终止点
    %
    setOpen = [startposind]; setOpenCosts = [0]; setOpenHeuristics = [Inf];
    setClosed = []; setClosedCosts = [];
    movementdirections = {'R','L','D','U'}; 
        while ~max(ismember(setOpen,goalposind)) && ~isempty(setOpen)

            [temp, ii] = min(setOpenCosts + weight*setOpenHeuristics);     %寻找拓展出来的最小值加上权重比

            %这个函数的作用就是把输入的点作为父节点，然后进行拓展找到子节点，并且找到子节点的代价，并且把子节点距离终点的代价找到
            [costs,heuristics,posinds] = findFValue_weight(setOpen(ii),setOpenCosts(ii),Indus_field,goalposind,'euclidean');

          setClosed = [setClosed; setOpen(ii)];     % 将找出来的拓展出来的点中代价最小的那个点串到矩阵setClosed 中 
          setClosedCosts = [setClosedCosts; setOpenCosts(ii)];    % 将拓展出来的点中代价最小的那个点的代价串到矩阵setClosedCosts 中

          % 从setOpen中删除刚才放到矩阵setClosed中的那个点
          %如果这个点位于矩阵的内部
          if (ii > 1 && ii < length(setOpen))
            setOpen = [setOpen(1:ii-1); setOpen(ii+1:end)];
            setOpenCosts = [setOpenCosts(1:ii-1); setOpenCosts(ii+1:end)];
            setOpenHeuristics = [setOpenHeuristics(1:ii-1); setOpenHeuristics(ii+1:end)];

          %如果这个点位于矩阵第一行
          elseif (ii == 1)
            setOpen = setOpen(2:end);
            setOpenCosts = setOpenCosts(2:end);
            setOpenHeuristics = setOpenHeuristics(2:end);

          %如果这个点位于矩阵的最后一行
          else
            setOpen = setOpen(1:end-1);
            setOpenCosts = setOpenCosts(1:end-1);
            setOpenHeuristics = setOpenHeuristics(1:end-1);
          end

         %%  
          % 把拓展出来的点中符合要求的点放到setOpen 矩阵中，作为待选点
          for jj=1:length(posinds)

            if ~isinf(costs(jj))   % 判断该点（方格）处没有障碍物

              % 判断一下该点是否 已经存在于setOpen 矩阵或者setClosed 矩阵中
              % 如果我们要处理的拓展点既不在setOpen 矩阵，也不在setClosed 矩阵中
              if ~max([setClosed; setOpen] == posinds(jj))
                fieldpointers(posinds(jj)) = movementdirections(jj);
                costchart(posinds(jj)) = costs(jj);
                setOpen = [setOpen; posinds(jj)];
                setOpenCosts = [setOpenCosts; costs(jj)];
                setOpenHeuristics = [setOpenHeuristics; heuristics(jj)];

              % 如果我们要处理的拓展点已经在setOpen 矩阵中
              elseif max(setOpen == posinds(jj))
                I = find(setOpen == posinds(jj));
                % 如果通过目前的方法找到的这个点，比之前的方法好（代价小）就更新这个点
                if setOpenCosts(I) > costs(jj)
                  costchart(setOpen(I)) = costs(jj);
                  setOpenCosts(I) = costs(jj);
                  setOpenHeuristics(I) = heuristics(jj);
                  fieldpointers(setOpen(I)) = movementdirections(jj);
                end

                % 如果我们要处理的拓展点已经在setClosed 矩阵中
              else
                I = find(setClosed == posinds(jj));
                % 如果通过目前的方法找到的这个点，比之前的方法好（代价小）就更新这个点
                if setClosedCosts(I) > costs(jj)
                  costchart(setClosed(I)) = costs(jj);
                  setClosedCosts(I) = costs(jj);
                  fieldpointers(setClosed(I)) = movementdirections(jj);
                end
              end
            end
          end

         %% 
          if isempty(setOpen) break; end
          set(axishandle,'CData',[costchart costchart(:,end); costchart(end,:) costchart(end,end)]);
          set(gca,'CLim',[0 1.1*max(costchart(costchart < Inf))]);
          drawnow; 
        end

        %通过路径回溯，找到优化路径Done_data,Info_Drones；
        %调用findWayBack函数进行路径回溯，并绘制出路径曲线
        if max(ismember(setOpen,goalposind))
          disp('Solution found! Total longth is');
          [p,Road_Long] = findWayBack(goalposind,fieldpointers,Road_Long); % 调用findWayBack函数进行路径回溯，将回溯结果放于矩阵P中
          %EachRoad(Rt,:)=Road_Long;
          %Road_Long_per=Road_Long-Road_Long_per;
          disp(Road_Long);
          plot(p(:,2)+0.5,p(:,1)+0.5,'Color',0.2*ones(3,1),'LineWidth',4);  %用 plot函数绘制路径曲线
          drawnow;
          drawnow;
        end
end

