
function [field, startposind, goalposind, costchart, fieldpointers] = Reset_G_S(field, startposind, goalposind, costchart, fieldpointers,New_startposind,New_goalposind)
    
   %在initializeField函数创建环境时，将field矩阵中没有障碍物的点处设定为10，有障碍物的点处设定为inf，起始点和终止点设为0
   %现在需要将新的起始点和终止点处设为0，原来起始点和终止点处设为10
    field(startposind) = 10; field(goalposind) = 10;  
    field(New_startposind) = 0; field(New_goalposind) = 0;  
   
    %在initializeField函数创建环境时，将costchart矩阵中的起始点设定为0，其他点设定为NAN
    %现在需要将新的起始点设定为0，原来的起始点设定为1
    costchart(startposind) = NaN;
    costchart(New_startposind) =0;
    
    % 在initializeField函数创建环境时，将fieldpointers元胞数组中起始点的位置处设为'S'，终止点处设为'G'，有障碍物的点设为'0'，没有障碍物的点设为'1'
    % 现在需要将新的起始点处设为'S'，新的终止点处设为'G'，原来的起始点和终止点处设为'1'
    fieldpointers{startposind} = '1'; fieldpointers{goalposind} = '1'; 
    fieldpointers{New_startposind} = 'S'; fieldpointers{New_goalposind} = 'G'; 
  
    %最后我们将新的起始点和新的终止点的索引值分别赋值给startposind和goalposind进行输出
    startposind=New_startposind;
    goalposind=New_goalposind;
end
