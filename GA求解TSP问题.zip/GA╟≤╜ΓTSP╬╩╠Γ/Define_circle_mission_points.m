% clear all
% close all
% clc
% 
% Nb_Mission_type1=10;Nb_Mission_type2=7;
% Circle_centre={[25,36] [26,5] [35,70]};
% Obstacle_zone_fix_totale=[];
% [r,l]=size(Circle_centre);centre_x=zeros([r l]);centre_y=zeros([r l]);Missions_points_totals=[];
% for i=1:l
%     centre_x(r,i)=Circle_centre{1,i}(1,1);
%     centre_y(r,i)=Circle_centre{1,i}(1,2);
%     [Missions_points_per_circle{i},Obstacle_zone_fix_per_circle{i}]=Define_mission_points(centre_x(r,i),centre_y(r,i),Nb_Mission_type1,Nb_Mission_type2);
%     Obstacle_zone_fix_totale=[Obstacle_zone_fix_totale;Obstacle_zone_fix_per_circle{1,i}];
%     Missions_points_totals=[Missions_points_totals;Missions_points_per_circle{1,i}];
% end
% %, Obstacle_x{i},Mission_points_x{i},Obstacle_X{i}

function  [Missions_points_per_circle, Obstacle_zone_fix_per_circle]=Define_circle_mission_points(centre_x,centre_y,Nb_Mission_type1,Nb_Mission_type2)
r=22.5;theta=0:pi/100:2*pi;dist=10;%rho=r*sin(theta)；%定义停下来执行任务的点距离建筑物2m
Nb_Mission_points=[Nb_Mission_type1 Nb_Mission_type2];
Mission_points_x=cell(size(Nb_Mission_points));
Mission_points_y=cell(size(Nb_Mission_points));
Obstacle_x=zeros([ length(Nb_Mission_points) length(theta)]);
Obstacle_y=zeros([ length(Nb_Mission_points) length(theta)]);
%Mission_points_vector_x=zeros([ length(Nb_Mission_points) sum(Nb_Mission_points)  ]);Mission_points_vector_y=zeros([ length(Nb_Mission_points) sum(Nb_Mission_points)  ]);
%圆圈：建筑障碍物
% points has the same distance,确认要进行的任务点及特殊任务点
for i=1:length(Nb_Mission_points)    
    Circle_x=centre_x+r*cos(theta); Circle_y=centre_y+(r)*sin(theta);
    Obstacle_x(i,:)=centre_x+(r-1)*cos(theta); Obstacle_y(i,:)=centre_y+(r-1)*sin(theta); 
    
    % points has the same distance
    Cx=(r+dist)*cos((0:Nb_Mission_points(i))*2*pi/Nb_Mission_points(i))+centre_x;
    Cy=(r+dist)*sin((0:Nb_Mission_points(i))*2*pi/Nb_Mission_points(i))+centre_y;
    Mission_points_x{i}=Cx;
    Mission_points_y{i}=Cy;
    
    %subplot(1,length(n),i)
    plot(Circle_x,Circle_y)
    hold on
    plot(centre_x,centre_y,'*')
    plot(Cx,Cy,'o')
    title(sprintf('Industrial Map '))

 
end
%Obstacle_points_fix(i,:)=[];%直接转换成ind索引坐标
    Obstacle_X=fix(reshape(Obstacle_x,[],1)) ;Obstacle_Y=fix(reshape(Obstacle_y,[],1));
    Obstacle_zone=[floor(Obstacle_X/10), floor(Obstacle_Y/10)];
    Obstacle_zone_fix_per_circle=unique(Obstacle_zone,'row');
    
   
    Mission_points_vector_x=cell2mat(Mission_points_x)';
    Mission_points_vector_y=cell2mat(Mission_points_y)';

    Missions_points_per_circle= [Mission_points_vector_x, Mission_points_vector_y];


end




%xlswrite('REPORT(revised)',c,'C2:AF49')