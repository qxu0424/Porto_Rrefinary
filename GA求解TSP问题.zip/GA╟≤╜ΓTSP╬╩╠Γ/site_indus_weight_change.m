clear all
close all
clc
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Environmental set
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('map_industrie')
Nb_nodes=400;%总共节点数量
Indus_field=reshape(1:Nb_nodes,[],20);%400个点排成矩形 定义初始化工厂矩阵

Delta_x=(0:10:190)';Delta_y=0:10:190;
X_nodes=repmat(Delta_x,20,1); Y_nodes=repelem(Delta_y,20)';%每个相同间距重复20次然后换行
XYCoords=[X_nodes Y_nodes];
[Indus_field_x, Indus_field_y]=ind2sub([20 20],Indus_field);%z坐标系转换，得到指数坐标（虽然好像并没有什么用）

%定义横向起始点和目的点
Site_nodes_source=[1:399 ]';
Site_nodes_target=[2:400 ]';
%排除没有可能的横向连接点
Except_source=[20:20:400];Except_target=[21:20:400];
Site_propriety(:,1)= setdiff(Site_nodes_source,Except_source);
Site_propriety(:,2)=setdiff(Site_nodes_target,Except_target);
%竖向连接建立
Vertical_link_s= [1:400-20]';Vertical_link_t=[21:400]';
%横竖总结，定义附加值
Source_nodes=[ Site_propriety(:,1) ;Vertical_link_s];
Target_nodes=[Site_propriety(:,2); Vertical_link_t ];
weights = round(3 + 10*rand(size(Target_nodes)));
names=sprintfc('%g',1:1: Nb_nodes);%定义每个节点名称%
G = graph(Source_nodes,Target_nodes,weights,names);
A=adjacency(G);
gplot(A,XYCoords,'-*');

%x=1:1:Nb_nodes(1);y=1:1:Nb_nodes(1);
%graph=plot(G,'XData',x,'YData',y,'EdgeLabel',G.Edges.Weight);

hold on


%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%确定工厂地址（画圆）， 选区附近的整数点,将其设置为障碍物的位置
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Nb_Mission_type1=4;Nb_Mission_type2=1;%Missions_points_per_circle={};
Circle_centre={ [60,60] [60,140] [140,60] [140, 140] };
[r,l]=size(Circle_centre);centre_x=zeros([r l]);centre_y=zeros([r l]);
Obstacle_zone_fix_totale=[];Missions_points_totals=[];%所有任务点x,y形式表示任务点
for i=1:l
    centre_x(r,i)=Circle_centre{1,i}(1,1);
    centre_y(r,i)=Circle_centre{1,i}(1,2);
    [Missions_points_per_circle{i},Obstacle_zone_fix_per_circle{i}]=Define_circle_mission_points(centre_x(r,i),centre_y(r,i),Nb_Mission_type1,Nb_Mission_type2);
    Obstacle_zone_fix_totale=[Obstacle_zone_fix_totale;Obstacle_zone_fix_per_circle{1,i}];
    Missions_points_totals=[Missions_points_totals;Missions_points_per_circle{1,i}];
end
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%选取障碍物的位置，并将其值设为Inf，包括固定障碍物和随机障碍物 
disp('fixed Obstacle designed')
[h_Obs,l_Obs]=size(Obstacle_zone_fix_totale);FixedObstacleind=zeros(h_Obs,1);%Obstacle_points_fix=zeros(h_Obs,2);
for i=1:h_Obs
Indus_field(Obstacle_zone_fix_totale(i,2),Obstacle_zone_fix_totale(i,1))=inf;
FixedObstacleind(i,1)=sub2ind([20 20],Obstacle_zone_fix_totale(i,2),Obstacle_zone_fix_totale(i,1));
end
disp('生成随机障碍物')
RandomObstacleposind=ceil(20^2.*rand(20*20*0.05,1));
Indus_field(ind2sub([20 20],RandomObstacleposind))=inf;
Obstacleposind_total=[FixedObstacleind; RandomObstacleposind];


%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 定义各个中心点的坐标  分割区域，中心工厂对应坐标% 为选取Base Station做准备
%生成任意边长等间距正六边形采样点给定六边形的边长数量n，且n为正整数
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
n=5;  d=25;
x=zeros(n,n+1);  y=zeros(n,n+1);  
X=zeros(n,n+1);  Y=zeros(n,n+1); 
theta=0:(2*pi/6):2*pi;
for i=1:n+1  
    for j=1:n+1  
        x(i,j)=3/2*(i-1);  
     if mod(i,2)==1
        y(i,j)=sqrt(3)*(j-1);
     else
        y(i,j)=sqrt(3)*(j-1)-sqrt(3)/2;
     end  
     %theta=linspace(0,2*pi,7);
    X(i,j)=x(i,j)*d;Y(i,j)=y(i,j)*d;
    %plot(cos(theta)+x(i,j),sin(theta)+y(i,j),'x');
    plot(cos(theta)*d+X(i,j),sin(theta)*d+Y(i,j),'y-');
    hold on
    end 
end
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%从六边形中心点集合中随机选取一点作为Base Station初始点， 即路程开始处总共有两个基站？
Nb_Base_station=2;
rand_index = [2,6];
%randi([2,length(X)],[1,Nb_Base_station]);%将序号随机排列,给出随便两个横坐标的索引指数
%draw_rand_index = rand_index(1:Nb_Base_station);%取出前m个序号中前Nb_base_station(两)个
Base_station_x= X(rand_index,1);Base_station_y= Y(rand_index,2);%通过确定y方向上的索引 取出这m个序号对应的X，Y元素 %注，这里可以增加变量 Y 方向上的
Coords_Base_station = [Base_station_x, Base_station_y];%第一列为x,第二列为y数值坐标
plot(Base_station_x,Base_station_y,'s')%将基站在图上显示出来

%总共是用三个矩阵 
%出发点与终点暂时选为相同，工厂初始化矩阵中起始点和终止点处的值设为0
Indus_field([5,rand_index(1,1)])=0;
Indus_field(sub2ind([20 20],[5 rand_index(1,2)]))=0;%因索引顺序语自己所建图不同，所以x,y换顺序
%花费矩阵如下,与weight那个矩阵相联系（可直接将个矩阵重塑）
costchart = NaN*ones(20,20);
startpossub_x=floor(Coords_Base_station(1,1)/10);startpossub_y=floor(Coords_Base_station(1,2)/10);
startposind= sub2ind([20 20],startpossub_y,startpossub_x);%因索引顺序语自己所建图不同，所以x,y换顺序
finalpossub_x=floor(Coords_Base_station(2,1)/10);finalpossub_y=floor(Coords_Base_station(2,2)/10);
finalgoalposind=sub2ind([20 20],finalpossub_y,finalpossub_x);
costchart(startposind) = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%确认所有任务点
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Missions_points_ind=zeros(length(Missions_points_totals),1);%Missions_points_totals坐标值转换为索引值，便于之后表示
for i=1:length(Missions_points_totals)%Missions points里选取较长想开始循环，这里为列，与任务总数相对应
Missions_points_ind(i,1)=sub2ind([20 20],fix(Missions_points_totals(i,2)/10),fix(Missions_points_totals(i,1)/10));
end
golpoints=unique([Missions_points_ind' finalgoalposind]);%第一个基站始发到第二个基站休息%所有无重复目的地索引
goalpoints_can_not_visit= intersect(golpoints,Obstacleposind_total);%与障碍物重合的目的地索引,既无法到达的目的地
goalpoints=setdiff(golpoints,goalpoints_can_not_visit);%减去不能去的目的地，最终得到可以到达的目的地
%goalpoints=golpoints;
goalposind=goalpoints(1);%第一个要去的目的地为所有目的地中的第一个

%第三个指路用矩阵
fieldpointers = cell(20,20);%生成元胞数组n*n
fieldpointers{startposind} = 'S'; fieldpointers{goalposind} = 'G'; %将元胞数组的起始点的位置处设为 'S'，终止点处设为'G'
fieldpointers(Indus_field==inf)={0};

%%
%暂时将初始点视为充电站，未定义周边的Mission points(之后有时间可加)
Rect_wide=15;Rect_high=10;Rectx=Coords_Base_station(1,1);Recty=Coords_Base_station(1,2);
rect=rectangle('Position',[Rectx,Recty,Rect_wide,Rect_high],'Curvature',[0.3,0.2],'EdgeColor','red');% 从点(x,y)开始绘制一个宽w高h的矩形，对坐标轴数据单元指定值。
%Rectangle_center=[Rectx,Recty];
rect.LineStyle= '- -';hold on;

Road_Long_sum=0; weight=2;
Road_Long=0;%用来存放规划的路径的长度
Environmental_Set=0;%环境不用改，只要改始终点就行，每次记录得路径长度，然后再用GA转换去Mission points的顺序以求的最优解，SED则用于游览不同Site之间的顺序
Reset_GS=0; Rt=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% A*算法计算每段任务点之间的长度的长度
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Allpassposind_total=[startposind goalpoints];
Each_road_length=zeros(length(Allpassposind_total),length(Allpassposind_total));
axishandle = createFigure(Indus_field,costchart,startposind,goalposind);
%%
%：除了起始点的所有目标点
tic
for m=1:length(Allpassposind_total)
    for n=m:length(Allpassposind_total)
        if m==n
            Each_road_length(m,n)=0;
            
        else
             if(Reset_GS)
        [Indus_field, startposind, goalposind, costchart, fieldpointers] = Reset_G_S(Indus_field, startposind, goalposind, costchart, fieldpointers,New_startposind,New_goalposind);
              end
             [Road_Long]=Algo_A_star_weight(Indus_field, startposind,goalposind, costchart,fieldpointers);
             Each_road_length(m,n)=Road_Long;
             Reset_GS=1; %原本的
             New_startposind=Allpassposind_total(m);  %为进行多次数值寻找重新设定起始点和终止点 goalposind
             New_goalposind=Allpassposind_total(n);
        end
    end
end
toc
%% 退火算法输入数据
 tic

MaxIt = 90000;%最大迭代次数
T0 = 8000;initial_T = T0;%初始最高温度
Tf = 0.0000000000000001; cooling_stop = Tf; %结束温度
cooling_ratio = 0.8;      %退火速度 sets the cooling ratio to 0.8  i.e. 0.7 < 0.8 < 0.9
cooling_sched = zeros(1);               %pre-allocation for speed
cooling_sched(1) = initial_T;                 %initializes the cooling schedule T0
%% 遗传算法参数设置
%vertexs=[x;y]';
n=length(Allpassposind_total);      %任务点数目/染色体长度/路线点数
dist=Each_road_length+Each_road_length';             %距离矩阵
NIND=85;                        %种群大小
MAXGEN=900;                    %迭代次数
Pc=0.8;                         %交叉概率
Pm=0.2;                         %变异概率
pSwap=0.2;                      %选择交换结构的概率
pReversion=0.5;                 %选择逆转结构的概率
pInsertion=1-pSwap-pReversion;  %选择插入结构的概率
N=n;                            %染色体长度=城市数目
%% 种群初始化
Chrom=InitPop(NIND,N);
                         
%% 混合算法优化
gen=1;                          %计数器             
bestChrom=Chrom(1,:);           %初始全局最优个体
bestL=RouteLength(bestChrom,dist);%初始全局最优个体的总距离
BestChrom=zeros(MAXGEN,N);      %预设记录每次迭代过程中全局最优个体
BestL=zeros(MAXGEN,1);          %记录每次迭代过程中全局最优个体的总距离
while cooling_sched(gen) > cooling_stop     %iteration will stop if the cooling temperature reached less than 0.00000001 迭代终止条件
    
while gen<=MAXGEN
    T = cooling_sched(gen);  %设置起始温度T的值
    %二元锦标赛选择
    SelCh=BinaryTourment_Select_T(Chrom,dist,T);%每次开始就计算适应度，选择
    SelCh=Recombin(SelCh,Pc);%OX交叉
    SelCh=Mutate(SelCh,Pm,pSwap,pReversion,pInsertion);%变异
    Chrom=SelCh;        %将Chrom更新为SelCh得到新种群
   
    Obj=ObjFunction(Chrom,dist); %计算当前代所有个体总距离
    
    [minObj,minIndex]=min(Obj);%找出当前代中最优个体
    
    %将当前代中最优个体与全局最优个体进行比较，如果当前代最优个体更好，则将全局最优个体进行替换
    if minObj<=bestL
        bestChrom=Chrom(minIndex,:);
        bestL=minObj;
        
    end
    %记录每一代全局最优个体，及其总距离
    BestChrom(gen,:)=bestChrom;
    BestL(gen,:)=bestL;
    %显示外层循环每次迭代的信全局最优路线的总距离
    disp(['' num2str(gen) 'th time：Global optimal route total distance= ' num2str(bestL)]);
    %画出每次迭代的全局最优路线图
    %figure(1);
    PlotRoute(bestChrom,[X(2,2); Missions_points_totals(:,1) ;X(6,2)],[Y(2,2);Missions_points_totals(:,2);Y(6,2)]);
    %pause(0.01);
    %计数器加1   
    gen=gen+1;
    cooling_sched(gen+1) = T*(cooling_ratio)^gen;%降温退火 ，0<ratio<1 。r越大，降温越慢；r越小，降温越快.若r过大，则搜索到全局最优解的可能会较高，但搜索的过程也就较长。若r过小，则搜索的过程会很快，但最终可能会达到一个局部最优值
    if gen > MaxIt
       break;  
     end

 
 end
end


 

%% 打印每次迭代的全局最优个体的总距离变化趋势图
figure;
plot(BestL,'LineWidth',1);
title('Optimization process')
xlabel('Number of iterations');
ylabel('Total distance calculated by GA');
toc

% %计算这样能到达最优值， 目标函数
% Nb_Dri=2;
% Self_cost=Nb_Dri*Prx_Dri+Prx_BS*Nb_BS;
% Use_cost=Maintenance_cost+Eng_cost;
% %Maintenance_cost=tps*Pr_i*Prx_Dri+sum(Prx_repair_i*NbDr_i);
% %Total_Cost=Self_cost+Use_cost+Maintenance_cost;
% T_trajectoire=2;
% T_missions=3;
% T_charge=4;
% T_maintenance=5;
% Temps=T_trajectoire+T_missions+T_charge+T_maintenance;

%%

%%

%% 
%%
